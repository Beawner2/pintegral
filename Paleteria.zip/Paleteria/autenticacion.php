<?php
include "abre.php";

// Datos del formulario de login
$nombre_usuario = $_POST['nombre_usuario'];
$contrasena = $_POST['contrasena'];

// Consulta para obtener el hash de la base de datos
$sql = "SELECT contrasena FROM usuario WHERE nombre_usuario = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param('s', $nombre_usuario);
$stmt->execute();
$stmt->store_result();

// Verificar si el usuario existe
if ($stmt->num_rows > 0) {
    $stmt->bind_result($hash);
    $stmt->fetch();

    // Verificar la contraseña ingresada con el hash
    if (password_verify($contrasena, $hash)) {
        // Inicio de sesión exitoso
        session_start();
        $_SESSION['usuario'] = $nombre_usuario;
        header("Location: catalogo.php"); // Redirigir al catálogo
        exit;
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "Usuario no encontrado.";
}

$stmt->close();
$conexion->close();
?>