<?php
include("abre.php");

$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$descripcion = $_POST['descripcion'];

$imagen = addslashes(string: file_get_contents(filename: $_FILES['imagen']['tmp_name']));

$sql = "INSERT INTO producto (nombre, descripcion, precio, imagen) VALUES ('$nombre', '$descripcion', '$precio', '$imagen')";

if ($conn->query($sql) === TRUE) {
    echo "Producto agregado correctamente";
    header('Location: catalogo.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

        