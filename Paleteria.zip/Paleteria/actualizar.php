<?php
include "abre.php";

// Validar que todos los campos están presentes
$id = $_REQUEST['id'];

$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$precio = $_POST['precio'];

if (isset($_FILES['imagen']) && $_FILES['imagen']['tmp_name'] != '') {
    $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
} else {
    $imagen = null;  // O alguna acción en caso de que no se suba ninguna imagen
}
// Consulta SQL para actualizar
$consulta = "UPDATE producto SET nombre='$nombre', descripcion='$descripcion', precio='$precio', imagen='$imagen' WHERE id='$id'";


if ($conn->query($consulta) === TRUE) {
    // Redirección antes de cualquier salida
    header("Location: catalogo.php");
    exit();
} else {

    echo "Error: " . $consulta . "<br>" . $conn->error;
}

$conn->close();
