<?php
include("abre.php");

if (!empty($_POST["btnIngresar"])) {
    if (empty($_POST["username"]) || empty($_POST["password"])) {
        echo "No hay nada en los campos";
    } else {
        $usuario = $_POST["username"];
        $password = $_POST["password"];

        // Consulta segura con sentencias preparadas
        $stmt = $conn->prepare("SELECT nombreUsuario, contraseña FROM usuario WHERE nombreUsuario = ?");
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($datos = $result->fetch_object()) {
            if (password_verify($password, $datos->contraseña)) {
                header("Location: index.html");
                exit();
            } else {
                echo "Contraseña incorrecta o mal desencriptada";
            }
        } else {
            echo "Usuario incorrecto";
        }
    }
}
?>